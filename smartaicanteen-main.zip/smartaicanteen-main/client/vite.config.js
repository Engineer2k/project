export default defineConfig({
  plugins: [react()],
  server: {
    historyApiFallback: true,
  },
});
