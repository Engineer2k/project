import mongoose from 'mongoose';

const offerSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  discountPercent: {
    type: Number
  },
  image: {
    type: String,
    required: true
  },
  tag: {
    type: String,
    required: true
  },
  expiryDate: {
    type: Date
  },
  active: {
    type: Boolean,
    default: true
  },
  code: {
    type: String
  }
}, { timestamps: true });

export const Offer = mongoose.model('Offer', offerSchema);