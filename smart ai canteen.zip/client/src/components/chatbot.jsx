import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { sendChatbotMessage } from "@/lib/openai";

export default function Chatbot() {
  const [messages, setMessages] = useState([{
    id: 1,
    content: "Hello! How can I help you with your meal today?",
    role: 'assistant'
  }]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  
  const messagesEndRef = useRef(null);

  // Scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async (e) => {
    if (e) e.preventDefault();
    
    if (!input.trim()) return;
    
    const userMessage = {
      id: Date.now(),
      content: input,
      role: 'user'
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);
    
    try {
      // Send message to chatbot API
      const response = await sendChatbotMessage(input);
      
      // Add assistant response
      const assistantMessage = {
        id: Date.now() + 1,
        content: response,
        role: 'assistant'
      };
      
      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error("Error sending message to chatbot:", error);
      
      // Add error message
      const errorMessage = {
        id: Date.now() + 1,
        content: "Sorry, I'm having trouble connecting. Please try again later.",
        role: 'assistant'
      };
      
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="flex flex-col h-full">
      <CardContent className="flex flex-col p-4 flex-grow">
        <div className="flex items-center mb-4">
          <div className="bg-accent rounded-full w-10 h-10 flex items-center justify-center text-white animate-pulse">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
              <path d="M12 2a2 2 0 0 1 2 2c0 .74-.4 1.39-1 1.73V7h1a7 7 0 0 1 7 7h1a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-1v1a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-1H2a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1h1a7 7 0 0 1 7-7h1V5.73c-.6-.34-1-.99-1-1.73a2 2 0 0 1 2-2z"></path>
              <path d="M7 12h10"></path>
              <path d="M7 16h10"></path>
              <path d="M10 9v3"></path>
              <path d="M14 9v3"></path>
            </svg>
          </div>
          <p className="ml-2 font-medium">CanteenBot</p>
        </div>
        
        <div className="space-y-3 mb-4 overflow-y-auto flex-grow">
          {messages.map((message) => (
            <div key={message.id} className={`flex ${message.role === 'user' ? 'justify-end' : ''}`}>
              <div 
                className={`${
                  message.role === 'user'
                    ? 'bg-neutral-100 rounded-xl rounded-tr-none'
                    : 'bg-accent/10 rounded-xl rounded-tl-none'
                  } py-2 px-4 max-w-[80%]`}
              >
                <p className="text-sm whitespace-pre-wrap">{message.content}</p>
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex">
              <div className="bg-accent/10 rounded-xl rounded-tl-none py-2 px-4">
                <div className="flex space-x-2">
                  <div className="w-2 h-2 bg-accent/50 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                  <div className="w-2 h-2 bg-accent/50 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                  <div className="w-2 h-2 bg-accent/50 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
        
        <form onSubmit={handleSendMessage} className="flex items-center mt-4">
          <Input
            type="text"
            placeholder="Ask me anything..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="w-full border border-neutral-300 rounded-lg py-2 px-4 focus:outline-none focus:ring-2 focus:ring-accent"
            disabled={isLoading}
          />
          <Button 
            type="submit"
            className="ml-2 bg-accent text-white p-2 rounded-lg h-10 w-10 flex items-center justify-center"
            disabled={!input.trim() || isLoading}
          >
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
              <line x1="22" y1="2" x2="11" y2="13"></line>
              <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
            </svg>
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}